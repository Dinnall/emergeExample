import React from 'react';
class Header extends React.Component{
	render(){
		return (
			<div className="Header">
				CC Payment Calculator
			</div>
		);
	}
}
export default Header;